const fs = require('fs');
const path = require('path');
const express = require('express');
require('dotenv').config();
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
// express app creation
const Book = require('./models/Book');
const app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({extended:true}));
const { check, validationResult } = require('express-validator');
app.post('/form', [ check('authors').isLength({ min: 3 }),
                                 check('bookName').isLength({min:3}),
                                 check('price').isNumeric()
                                ], 
                    (req, res) => {
                       const errors = validationResult(req);
                       if (!errors.isEmpty()) {
                          return res.status(422).json({ errors: errors.array() });
                       }
                       const authors = req.body.authors;
                       const bookName = req.body.bookName;
                       const price = req.body.price;
	    
                 });
                 
                 mongoose.connect(process.env.MONGO_URI)
                 .then((result)=>
                 {
                     console.log("CONNECTED TO MONGODB...");
                     app.listen(process.env.PORT, () =>
                     {
                         console.log(`listening to port ${process.env.PORT}`);
                     })
                 
                 }).then((err) =>
                 {
                     console.log(err);
                 });              


// the public folder as a static files folder (so that files are accessible to client requests)
app.use(express.static('public'));

app.set('view engine', 'ejs');


app.get('/add', (request, response) => {
    response.render('add');
  })

app.get('/Register', (request, response) => {
    response.render('Register');
  })


app.get('/Features', (request, response) => {
    response.render('Features');
  })

  const getAllBooks = (req, resp) => 
  {
      Book.find()
      .then((result) => {
      resp.render('books', {books:result});
  }).then((err) =>{
      console.log(err);
  }
  );
  }
  const router = express.Router();
  app.use('/books', router);

//ROUTER GETS GETALLBOOKS FUNCTION FOR ADDING
  router.get('/', getAllBooks);

  // ADD BOOK FUNCTION
  app.post('/books', (req, res) => {
    let newBook = new Book({
       authors: req.body.authors,
      bookName: req.body.bookName,
      imgSrc: req.body.imgSrc
  });
  newBook.save();
  res.redirect('/books');

  })
  
// REMAINING SEARCH + UPDATE + REMOVE HERE -->


// if no route corresponds to request render 404 page
app.use((request, response) => {
    response.status(404).render('404');
  })
  